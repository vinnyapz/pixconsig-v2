/*
  Warnings:

  - You are about to drop the `prefeitura_requests` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "prefeitura_requests" DROP CONSTRAINT "prefeitura_requests_requesterId_fkey";

-- DropForeignKey
ALTER TABLE "prefeitura_requests" DROP CONSTRAINT "prefeitura_requests_targetMasterId_fkey";

-- DropTable
DROP TABLE "prefeitura_requests";

-- DropEnum
DROP TYPE "RequestStatus";
