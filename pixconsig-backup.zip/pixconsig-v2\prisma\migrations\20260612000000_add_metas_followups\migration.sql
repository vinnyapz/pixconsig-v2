-- Tabela de metas mensais
CREATE TABLE "metas" (
    "id" TEXT NOT NULL,
    "month" INTEGER NOT NULL,
    "year" INTEGER NOT NULL,
    "targetCount" INTEGER NOT NULL,
    "targetAmount" DOUBLE PRECISION NOT NULL,
    "masterId" TEXT,
    "franqueadoId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "metas_pkey" PRIMARY KEY ("id")
);

-- Tabela de follow-ups
CREATE TABLE "follow_ups" (
    "id" TEXT NOT NULL,
    "prefeituraId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "dueDate" TIMESTAMP(3) NOT NULL,
    "done" BOOLEAN NOT NULL DEFAULT false,
    "createdById" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "follow_ups_pkey" PRIMARY KEY ("id")
);

-- Adicionar valor FOLLOWUP ao enum NotificationType (se não existir)
ALTER TYPE "NotificationType" ADD VALUE IF NOT EXISTS 'FOLLOWUP';

-- Foreign keys
ALTER TABLE "metas" ADD CONSTRAINT "metas_masterId_fkey" FOREIGN KEY ("masterId") REFERENCES "masters"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "metas" ADD CONSTRAINT "metas_franqueadoId_fkey" FOREIGN KEY ("franqueadoId") REFERENCES "franqueados"("id") ON DELETE SET NULL ON UPDATE CASCADE;
ALTER TABLE "follow_ups" ADD CONSTRAINT "follow_ups_prefeituraId_fkey" FOREIGN KEY ("prefeituraId") REFERENCES "prefeituras"("id") ON DELETE CASCADE ON UPDATE CASCADE;
