-- CreateEnum
CREATE TYPE "RequestStatus" AS ENUM ('PENDING', 'APPROVED', 'REJECTED');

-- CreateEnum
CREATE TYPE "RequesterType" AS ENUM ('MASTER', 'FRANQUEADO');

-- CreateTable
CREATE TABLE "prefeitura_requests" (
    "id" TEXT NOT NULL,
    "city" TEXT NOT NULL,
    "state" TEXT NOT NULL,
    "requesterType" "RequesterType" NOT NULL,
    "status" "RequestStatus" NOT NULL DEFAULT 'PENDING',
    "masterId" TEXT,
    "franqueadoId" TEXT,
    "prefeituraId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "prefeitura_requests_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "prefeitura_requests" ADD CONSTRAINT "prefeitura_requests_masterId_fkey" FOREIGN KEY ("masterId") REFERENCES "masters"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "prefeitura_requests" ADD CONSTRAINT "prefeitura_requests_franqueadoId_fkey" FOREIGN KEY ("franqueadoId") REFERENCES "franqueados"("id") ON DELETE SET NULL ON UPDATE CASCADE;
