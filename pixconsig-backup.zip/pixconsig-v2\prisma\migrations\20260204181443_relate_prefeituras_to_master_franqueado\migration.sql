-- DropForeignKey
ALTER TABLE "prefeituras" DROP CONSTRAINT "prefeituras_franqueadoId_fkey";

-- DropForeignKey
ALTER TABLE "prefeituras" DROP CONSTRAINT "prefeituras_masterId_fkey";

-- AddForeignKey
ALTER TABLE "prefeituras" ADD CONSTRAINT "prefeituras_masterId_fkey" FOREIGN KEY ("masterId") REFERENCES "masters"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "prefeituras" ADD CONSTRAINT "prefeituras_franqueadoId_fkey" FOREIGN KEY ("franqueadoId") REFERENCES "franqueados"("id") ON DELETE SET NULL ON UPDATE CASCADE;
